#include "ClasesPosix.h"
#include "Identificador.h"
#include <stdio.h>
using namespace std;

Identificador_t Identificador;

/*
**********************************************************
********************** Clase hilo_t **********************
**********************************************************
*/

// AQUÍ IRÁ LA IMPLEMENTACIÓN DE LA CLASE hilo_t DEFINIDA EN LA PRÁCTICA P0_1
hilo_t::hilo_t()
{

	// Guardar el resultado de Identificador.ObtenerId() en el atributo de clase que almacena el identificador del hilo
	identificador = Identificador.ObtenerId();
	// Inicialización de los atributos de creación del hilo
	pthread_attr_init(&atributos);
	// Inicialización de la función del hilo a NULL
	funcion = NULL;
	// Inicialización de los datos de la función del hilo a NULL
	dato = NULL;
}
// fin del constructor

// Implementación del destructor sin parámetros. Este método destruirá los atributos de creación del hilo y liberará la memoria de los atributos de la clase
hilo_t::~hilo_t()
{

	// Destrucción de los atributos de creación del hilo
	pthread_attr_destroy(&atributos);
}
// Fin del destructor

// Implementación del método Lanzar. Este método se encargará de lanzar un hilo usando la función y los datos almacenados en la clase
int hilo_t::Lanzar()
{

	// Si la función asociada existe (no es NULL)
	if(funcion != NULL)
	{
		/*Crear un hilo usando como parámetros la dirección de memoria al manejador del hilo, la dirección de memoria a los atributos de creación del hilo, la función del hilo y los datos del hilo.
		Se devolverá el resultado de la llamada a pthread_create*/
		return pthread_create(&manejador, &atributos, funcion, dato);
	}
	else
	{
		// Si la función asociada no existe
		// Devolver -1
		return -1;
	}
}
// Fin de Lanzar

// Implementación del método AsignarFuncion. Asignará el parámetro recibido al atributo que almacena la función del hilo
void hilo_t::AsignarFuncion(void *(*func)(void *))
{
	// Asignar el parámetro del método al atributo de la clase que almacena la función asociada
	funcion = func;
}
// Fin de AsignarFuncion

// Implementación del método AsignarDato. Asignará el parámetro recibido al atributo que almacena los datos que se usarán con la función del hilo
void hilo_t::AsignarDato(void *d)
{
	// Asignar el parámetro del método al atributo de la clase que almacena el parámetro que se usará con la función asociada
	dato = d;
}
// fin de AsignarDato

// Implementación del método AsignarFuncionYDato. Este método llamará a los métodos AsignarFuncion y AsignarDato con cada uno de sus parámetros
void hilo_t::AsignarFuncionYDato(void *(*func)(void *), void *d)
{
	// Llamar a AsignarFuncion
	AsignarFuncion(func);
	// Llamar a AsignarDato
	AsignarDato(d);
}
// Fin de AsignarFuncionYDato

// Implementación del método Join sin parámetros. Este método esperará por el hilo indicado por el manejador de la clase y retornará el valor devuelto por dicho hilo.
void *hilo_t::Join()
{
	// Definir una variable de tipo puntero a void (debe ser puntero a void para permitir que se pueda devolver cualquier tipo de dato). No hay que reservar memoria.
	void *var;
	// Esperar por el hilo asociado a la clase
	pthread_join(manejador, &var);
	// Devolver la variable definida en la primera línea del método.
	return var;
}
// Fin de Join

// Implementación de método ObtenerManejador sin parámetros. Este método devolverá el valor del manejador del hilo asociado a la clase.
void *hilo_t::ObtenerManejador()
{
	// Devolver el manejador del hilo
	return &manejador;
}
// Fin de ObtenerManejador

// Implementación de método ObtenerIdentificaror sin parámetros. Este método devolverá el valor del identificador del hilo asociado a la clase.
int hilo_t::ObtenerIdentificador()
{
	// Devolver el identificador del hilo
	return identificador;
}
// Fin de ObtenerIdentificaror



/*
**********************************************************
********************** Clase mutex_t *********************
**********************************************************
*/

//Implementación del constructor sin parámetros. Este método reservará memoria para los atributos de la clase e inicializará los atributos de creación del mutex
mutex_t::mutex_t(){
	//Inicialización de los atributos de creación del mutex
	pthread_mutexattr_init(&atributos);
}
//fin del constructor


//Implementación del destructor sin parámetros. Este método liberará la memoria de los atributos de la clase y destruirá el mutex y los atributos de creación del mutex
mutex_t::~mutex_t(){
	//Destrucción del mutex
	pthread_mutex_destroy(&manejador);

	//Destrucción de los atributos de creación del mutex
	pthread_mutexattr_destroy(&atributos);
}
//fin del destructor


//Implementación del método Inicializar sin parámetros. Este método se encargará de inicializar el mutex usando los atributos de creación del mutex
int mutex_t::Inicializar(){
	/*Inicializar el mutex asociado a la clase usando como parámetros el manejador del mutex y los atributos de creación del mutex.
	Debe retornar el valor que devuelva la función pthread_mutex_init*/
	return pthread_mutex_init(&manejador,&atributos);

}
//Fin de Inicializar


//Implementación del método Lock sin parámetros. Este método se encargará de acceder al mutex asociado a la clase usando el manejador del mutex de la clase
int mutex_t::Lock(){
	//Acceder al mutex con el manejador de la clase. Debe retornar el valor devuelto por dicha función.
	return pthread_mutex_lock(&manejador);
}
//Fin de Lock


//Implementación del método Unlock sin parámetros. Este método se encargará de liberar el mutex asociado a la clase usando el manejador del mutex de la clase
int mutex_t::Unlock(){
	//Liberar el mutex asociado a la clase usando como parámetro el manejador del mutex. Debe retornar el valor devuelto por dicha función.
	return pthread_mutex_unlock(&manejador);
}	
//Fin de Unlock


//Implementación del método ObtenerManejador sin parámetros. Este método se encargará devolver el manejador del mutex de la clase
 pthread_mutex_t *mutex_t::ObtenerManejador(){
	//Devolver el puntero al manejador del mutex de la clase, para lo que usaremos el operador & delante del nombre del mutex de la clase.
	return &manejador;
}
//Fin de ObtenerManejador


/*
**********************************************************
*************** Clase variable_condicion_t ***************
**********************************************************
*/

//Implementación del constructor sin parámetros. Este método reservará memoria para los atributos de la clase e inicializará los atributos de creación de la variable de condición
variable_condicion_t::variable_condicion_t(){
	//Inicialización de los atributos de creación de la variable de condición
	pthread_condattr_init(&atributos);
}
//Fin del constructor


/*Implementación del destructor sin parámetros. Este método destruirá la variable de condición y los atributos de creación de la variable de condición
y liberará la memoria de los atributos de la clase*/
variable_condicion_t::~variable_condicion_t(){
	//Destrucción de la variable de condición
	pthread_cond_destroy(&manejador);
	//Destrucción de los atributos de creación de la variable de condición
	pthread_condattr_destroy(&atributos);
}
//Fin del destructor


//Implementación del método Inicializar sin parámetros. Este método se encargará de inicializar la variable de condición usando los atributos de creación la variable de condición
int variable_condicion_t::Inicializar(){
	//Inicializar la variable de condición usando los atributos de clase manejador y atributos de creación la variable de condición. Debe retornar el valor que devuelva dicha función*/
	return pthread_cond_init(&manejador,&atributos);
}
//Fin de Inicializar


/*Implementación del método Inicializar con un parámetro de tipo puntero a pthread_mutex_t. Este método se encargará de asociar el mutex recibido por parámetro a la clase
(usar el método AsociarManejadorMutex) así como de inicializar la variable de condición usando los atributos de creación la variable de condición*/
int variable_condicion_t::Inicializar(pthread_mutex_t *mutex){
	//Llamar a AsociarManejadorMutex con el parámetro de entrada.
	AsociarManejadorMutex(mutex);
	//Inicializar la variable de condición usando los atributos de clase manejador y atributos de creación la variable de condición. Debe retornar el valor que devuelva dicha función
	return pthread_cond_init(&manejador,&atributos);
}
//Fin de inicializar


/*Implementación del método AsociarManejadorMutex con un parámetro de tipo puntero a pthread_mutex_t. Este método se encargará de asignar el parámetro de entrada de la función al
atributo de la clase que va a almacenar el mutex asociado. No es necesario reservar memoria para dicho atributo ya que, aunque es un puntero, también lo es el
parámetro de entrada. Al ser ambas variables punteros, el mutex asociado y el parámetro de entrada acabarán apuntando a la misma dirección de memoria.*/
void variable_condicion_t::AsociarManejadorMutex(pthread_mutex_t *mutex){
	//Asignar el parámetro de entrada al parámetro que almacenará el mutex asociado.
	this->mutex=mutex;
}
//Fin de AsociarManejadorMutex


//Implementación del método Wait sin parámetros. Este método se encargará de bloquear el hilo invocante en la variable de condición de la clase.
int variable_condicion_t::Wait(){
	/*Llamar a la función de bloqueo en una variable de condición con los atributos de la clase manejador de la variable de condición y mutex asociado.
	El método retornará el valor que devuelva dicha función.*/
	return pthread_cond_wait(&manejador,mutex);
}
//Fin de Wait


/*Implementación del método TimedWait con un parámetro de tipo struct timespec. Este método se encargará de bloquear el hilo en la variable de condición de la clase
como máximo hasta el instante indicado por el parámetro de entrada.*/
int variable_condicion_t::TimeWait(struct timespec time){
	/*Llamar a la función de bloqueo en una variable de cindición con límite temporal con los atributos de la clase manejador de la variable de condición, el mutex asociado
	junto con el paránetro de entrada. El método retornará el valor que devuelva dicha función.*/
	return pthread_cond_timedwait(&manejador,mutex,&time);
}
//Fin de TimedWait


//Implementación del método Signal sin parámetros. Este método se encargará de liberar (al menos) un hilo bloqueado en la variable de condición de la clase.
int variable_condicion_t::Signal(){
	/*Llamar a la función de liberación de (al menos) un hilo bloqueado en la variable de condición con el atributo de la clase manejador de la variable.
	El método retornará el valor que devuelva dicha función.*/
	return pthread_cond_signal(&manejador);
}
//Fin de Signal


//Implementación del método Broadcast sin parámetros. Este método se encargará de liberar todos los hilos bloqueados en la variable de condición de la clase.
int variable_condicion_t::Broadcast(){
	/*Llamar a la de liberación de todos los hilos bloqueados en cla variable de condición de la clase con el atributo de la clase manejador de la variable de condición.
	El método retornará el valor que devuelva dicha función.*/
	return pthread_cond_broadcast(&manejador);
}
//Fin de Broadcast

