#include "pila_acotada.h"
#include <stdio.h>

#define REPETICIONES 50
#define NUM_HILOS 5

void imprimir_lectura(int hilo, int elem)
{
	printf("El hilo %d ha leído el valor %d de la pila\n", hilo, elem);
}

void imprimir_escritura(int hilo, int elem)
{
	printf("El hilo %d ha añadido el valor %d a la pila\n", hilo, elem);
}

/*
Definir un tipo de datos DatosHilos_t que sea una estructura con dos campos:
- Identificador de hilo de puntero a hilo_t: este campo almacenará la dirección de memoria de la clase que almacena los datos del hilo para poder usarlos dentro de la función
- Pila acotada de tipo puntero a PilaAcotada: este campo servirá para que todos los hilos compartan la misma pila acotada (de ahí que sea un puntero)
Para definir un tipo se usa la palabra reservada typedef, mientras que para definir una estructura se usa la palabra reservada struct. Por tanto, para definir un
tipo estructura se deben incluir ambas palabras reservadas de la forma "typedef struct { campos de la estructura } NombreDelTipo;"
*/
typedef struct
{
	hilo_t *id;
	PilaAcotada *pila;
} DatosHilos_t;

// Definir la función hilo_productor para la creación de hilos productores siguiendo el formato específico de este tipo de funciones (ver apuntes del tema 2 o el anexo de la práctica 1)
void *hilo_productor(void *aux)
{
	// Definir una variable de tipo DatosHilos_t
	DatosHilos_t *var = (DatosHilos_t *)aux;
	// Asignar el contenido del parámetro de entrada a la variable anterior siguiento la forma indicada en clase (ver apuntes del tema 2 o el anexo de la práctica 1)

	int id = var->id->ObtenerIdentificador();
	/*
	Llamar REPETICIONES veces al método PilaAniadir del campo relativo a la pila acotada mostrando un mensaje con el número que se introducirá y el identificador del hilo
	Como en la estructura DatosHilos_t los campos son punteros, para usar sus métodos usaremos '->' en lugar de '.'
	*/

	for (int i = 0; i < REPETICIONES; i++)
	{

		imprimir_escritura(id, i + 1);

		var->pila->PilaAniadir(i + 1);
	}
	return nullptr;
}
// Fin hilo_productor

// Definir la función hilo_consumidor para la creación de hilos consumidores siguiendo el formato específico de este tipo de funciones (ver apuntes del tema 2 o el anexo de la práctica 1)
void *hilo_consumidor(void *aux)
{
	// Definir una variable de tipo DatosHilos_t
	DatosHilos_t *var = (DatosHilos_t *)aux;
	// Asignar el contenido del parámetro de entrada a la variable anterior siguiento la forma indicada en clase (ver apuntes del tema 2 o el anexo de la práctica 1)

	int id = var->id->ObtenerIdentificador();

	/*
	Llamar REPETICIONES veces al método PilaSacar del campo relativo a la pila acotada mostrando un mensaje con el número leído y el identificador del hilo
	Como en la estructura DatosHilos_t los campos son punteros, para usar sus métodos usaremos '->' en lugar de '.'
	*/
	int n;
	for (int i = 0; i < REPETICIONES; i++)
	{
		imprimir_lectura(id, var->pila->PilaSacar());
	}
	return nullptr;
}
// Fin hilo_consumidor

int main(void)
{
	// Definir una variable PilaAcotada inicializándola a 20
	PilaAcotada pila = PilaAcotada(20);
	// Definir dos vectores de tipo DatosHilos_t y de tamaño NUM_HILOS para almacenar los datos de los productores y de los consumidores (no usar la clase vector)
	DatosHilos_t vConsumidor[NUM_HILOS];
	DatosHilos_t vProductor[NUM_HILOS];
	// Crear dos vectores de tipo hilo_t y de tamaño NUM_HILOS para almacenar los objetos hilo_t de los productores y de los consumidores (no usar la clase vector)
	hilo_t vectorCon[NUM_HILOS];
	hilo_t vectorPro[NUM_HILOS];
	/*
	Lanzar los NUM_HILOS productores y consumidores. Para lanzar cada hilo, hay que hacer los siguientes pasos:
		1. Asignar al campo relativo al identificador del hilo de la posición i-ésimo de los vectores de tipo DatosHilos_t (productores/consumidores)
			i-ésimo de los vectores de hilos de productores/consumidores según corresponda
		2. Asignar al campo relativo a la pila acotada de la posición i-ésimo de los vectores de tipo DatosHilos_t (productores/consumidores) la dirección de memoria
			de la variable de tipo PilaAcotada definida al comienzo de la función main (poner & delante de la variable para acceder a su dirección de memoria)
		3. Asignar al hilo i-ésimo de los productores/consumidores la función hilo_productor/hilo_consumidor y la dirección de memoria del dato i-ésimo del
		productor/consumidor según corresponda
		4. Lanzar el hilo productor/consumidor -iésimo
	*/
	for (int i = 0; i < NUM_HILOS; i++)
	{
		// Consumidor
		vConsumidor[i].id = &vectorCon[i];
		vConsumidor[i].pila = &pila;
		vConsumidor[i].id->AsignarFuncionYDato(hilo_consumidor, &vConsumidor[i]);
		vConsumidor[i].id->Lanzar();

		// Productor
		vProductor[i].id = &vectorPro[i];

		vProductor[i].pila = &pila;

		vProductor[i].id->AsignarFuncionYDato(hilo_productor, &vProductor[i]);
		vProductor[i].id->Lanzar();
	}
	// Esperar a que terminen todos los productores y los consumidores
	for (int i = 0; i < NUM_HILOS; i++)
	{
		vConsumidor[i].id->Join();
		vProductor[i].id->Join();
	}


	return 0;
}
