#include "pila_acotada.h"
#include <stdio.h>


// Implementación del constructor sin parámetros
PilaAcotada::PilaAcotada()
{
	// Llamar al constructor con un parámetro usando 10 como parámetro
	tamMax = 10;
	mutex.Inicializar();
	pLlena.Inicializar();
	pVacia.Inicializar();
	pLlena.AsociarManejadorMutex(mutex.ObtenerManejador());
	pVacia.AsociarManejadorMutex(mutex.ObtenerManejador());

}
// Fin del constructor sin parámetros

// Implementación del constructor con un parámetro para indicar el tamaño máximo de la pila
PilaAcotada::PilaAcotada(int tam)
{
	// Inicializar el tamaño máximo de la pila con el parámetro de entrada del constructor
	tamMax = tam;
	// Inicializar el mutex de la clase
	mutex.Inicializar();
	// Inicializar las dos variables de condición de la clase
	pLlena.Inicializar();
	pVacia.Inicializar();
	// Asociar el mutex de la clase a las dos variables de condición de la clase. Para ello, hay que pasar el manejador del mutex al método AsociarManejadorMutex de las variables de condición
	pLlena.AsociarManejadorMutex(mutex.ObtenerManejador());
	pVacia.AsociarManejadorMutex(mutex.ObtenerManejador());
}
// fin del constructor con un parámetro

// Implementación del método PilaAniadir con un parámetro de entrada de tipo entero
void PilaAcotada::PilaAniadir(int n)
{
	// Acceder a la región crítica a través del mutex
	mutex.Lock();
	// Mientras la pila esté llena, bloquearse en la variable de condición de la pila llena
	while (vPila.size() == tamMax)
	{
		pLlena.Wait();
	}
	// Añadir elem en la cima de la pila
	vPila.push_back(n);
	// Liberar el mutex
	mutex.Unlock();
	// Liberar, al menos, un hilo de la variable de condición de la pila vacia
	pVacia.Signal();
}
// Fin del método PilaAniadir

// Implementación del método PilaSacar sin parámetros y que retorna un entero
int PilaAcotada::PilaSacar()
{
	// Acceder a la región crítica a través del mutex
	mutex.Lock();
	// Mientras la pila esté vacía, bloquearse en la variable de condición de la pila vacia
	while (vPila.size() == 0)
	{
		pVacia.Wait();
	}
	// Definir una variable entera y guardar ahí el valor contenido en la cima de la pila
	int n = vPila.back();
	// Eliminar el elemento contenido en la cima de la pila
	vPila.pop_back();
	// Liberar el mutex
	mutex.Unlock();
	// Liberar, al menos, un hilo de la variable de condición de la pila llena
	pLlena.Signal();
	// Devolver el elemento leído
	return n;
}

// Fin del método PilaSacar

PilaAcotada::~PilaAcotada(){

}